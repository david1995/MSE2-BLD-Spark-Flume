#!/bin/bash

exec dotnet SparkFlume.Output.dll --databaseserver localhost:3306
