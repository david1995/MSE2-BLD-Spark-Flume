﻿namespace SparkFlume.EventGenerator.Business
{
    public class ViewEvent : Event
    {
    }
}
