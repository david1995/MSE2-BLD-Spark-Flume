﻿namespace SparkFlume.EventGenerator.Business
{
    public class PurchaseEvent : Event
    {
        public decimal Revenue { get; set; }
    }
}
